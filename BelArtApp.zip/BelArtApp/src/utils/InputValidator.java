package utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * Classe pour valider et lire les entrées de l'utilisateur
 */
public class InputValidator {
    private static Scanner scanner = new Scanner(System.in);
    
    /**
     * Lit un entier avec validation
     * @param message Message à afficher
     * @param allowCancel Si true, 'r' peut annuler; sinon lecture normale
     * @return L'entier saisi, ou -1 si annulation avec 'r'
     */
    public static int lireEntier(String message, boolean allowCancel) {
        while (true) {
            try {
                System.out.print(message);
                String input = scanner.nextLine().trim();
                
                // Si l'utilisateur tape 'r' et que l'annulation est autorisée
                if (allowCancel && input.equalsIgnoreCase("r")) {
                    return -1;
                }
                
                int valeur = Integer.parseInt(input);
                
                // Si valeur négative
                if (valeur < 0) {
                    System.out.println("Veuillez entrer un nombre positif.");
                    continue;
                }
                
                // Retourne la valeur (y compris 0 si c'est la valeur saisi)
                return valeur;
                
            } catch (NumberFormatException e) {
                System.out.println("Entrée invalide. Veuillez entrer un nombre.");
            }
        }
    }
    
    /**
     * Lit une chaîne non vide avec validation
     * @param message Message à afficher
     * @return La chaîne saisie ou null si annulation
     */
    public static String lireChaine(String message) {
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine().trim();
            
            if (input.equalsIgnoreCase("r")) {
                return null; 
            }
            
            if (input.isEmpty()) {
                System.out.println("Ce champ ne peut pas être vide.");
                continue;
            }
            
            return input;
        }
    }
    
    /**
     * Lit une date avec validation
     * @param message Message à afficher
     * @return LocalDate ou null si annulation
     */
    public static LocalDate lireDate(String message) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        
        while (true) {
            System.out.print(message + " (YYYY-MM-DD) : ");
            String input = scanner.nextLine().trim();
            
            if (input.equalsIgnoreCase("r")) {
                return null; 
            }
            
            try {
                return LocalDate.parse(input, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Format de date invalide. Utilisez le format YYYY-MM-DD (ex: 2025-12-25)");
            }
        }
    }
    
    /**
     * Demande une confirmation (oui/non)
     * @param message Message à afficher
     * @return true si oui, false sinon
     */
    public static boolean confirmer(String message) {
        System.out.print(message + " (o/n) : ");
        String reponse = scanner.nextLine().trim();
        return reponse.equalsIgnoreCase("o") || reponse.equalsIgnoreCase("oui");
    }
    
    /**
     * Attend que l'utilisateur appuie sur Entrée
     */
    public static void pause() {
        System.out.println("\nAppuyez sur la touche Enter (Entrée) pour continuer");
        scanner.nextLine();
    }
    
    /**
     * Efface l'écran de la console (multi-plateforme)
     */
    public static void clearScreen() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                // Pour Windows
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                // Pour Unix/Linux/Mac
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Si ça ne marche pas, on affiche juste des lignes vides
            for (int i = 0; i < 50; i++) {
                System.out.println();
            }
        }
    }
    
    /**
     * Fermeture du scanner
     */
    public static void fermer() {
        scanner.close();
    }
}