package dao.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3306/BelartDB";
    private static final String USER = "root";
    private static final String PASSWORD = "Bithley24@"; 
    
    private static Connection connection = null;
    
    private DatabaseManager() {}
    
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (ClassNotFoundException e) {
                System.err.println("Driver MySQL non trouvé !");
                throw new SQLException("Driver MySQL introuvable", e);
            } catch (SQLException e) {
                System.err.println("Erreur l'ors de la connexion : " + e.getMessage());
                throw e;
            }
        }
        return connection;
    }
    
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Erreur lors de la fermeture : " + e.getMessage());
            }
        }
    }

    public static boolean testConnection() {
        try {
            Connection conn = getConnection();
            boolean isValid = conn != null && !conn.isClosed();
            if (isValid) {
                System.out.println("Connexion établie avec succès");
            }
            return isValid;
        } catch (SQLException e) {
            return false;
        }
    }
}