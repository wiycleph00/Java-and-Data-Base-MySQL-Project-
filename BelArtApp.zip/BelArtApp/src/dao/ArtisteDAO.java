package dao;

import models.Artiste;
import dao.database.DatabaseManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) pour gérer les artistes dans la base de données
 */
public class ArtisteDAO {
    
    /**
     * Ajoute un nouvel artiste dans la base de données
     * @param artiste L'artiste à ajouter
     * @return true si succès
     */
    public boolean ajouter(Artiste artiste) {
        String sql = "INSERT INTO Artiste (nom, prenom, nationalite) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, artiste.getNom());
            stmt.setString(2, artiste.getPrenom());
            stmt.setString(3, artiste.getNationalite());
            
            int rows = stmt.executeUpdate();
            
            // Récupéreration de l'ID généré automatiquement
            if (rows > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    artiste.setIdArtiste(rs.getInt(1));
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Une erreur s'est produite lors de l'ajout de l'artiste : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Récupère tous les artistes
     * @return Liste des artistes
     */
    public List<Artiste> getTous() {
        List<Artiste> artistes = new ArrayList<>();
        String sql = "SELECT * FROM Artiste ORDER BY nom, prenom";
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Artiste artiste = new Artiste(
                    rs.getInt("id_artiste"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("nationalite")
                );
                artistes.add(artiste);
            }
            
        } catch (SQLException e) {
            System.err.println("une erreur s'est produite lors de la récupération des artistes : " + e.getMessage());
        }
        
        return artistes;
    }
    
    /**
     * Récupère un artiste par son ID
     * @param id L'ID de l'artiste
     * @return L'artiste ou null si non trouvé
     */
    public Artiste getParId(int id) {
        String sql = "SELECT * FROM Artiste WHERE id_artiste = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Artiste(
                    rs.getInt("id_artiste"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("nationalite")
                );
            }
            
        } catch (SQLException e) {
            System.err.println("Une erreur s'est produite lors de la récupération de l'artiste : " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Recherche des artistes par nom (partiel)
     * @param nom Le nom à rechercher
     * @return Liste des artistes correspondants
     */
    public List<Artiste> rechercherParNom(String nom) {
        List<Artiste> artistes = new ArrayList<>();
        String sql = "SELECT * FROM Artiste WHERE LOWER(nom) LIKE LOWER(?) OR LOWER(prenom) LIKE LOWER(?) ORDER BY nom";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            String pattern = "%" + nom + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Artiste artiste = new Artiste(
                    rs.getInt("id_artiste"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("nationalite")
                );
                artistes.add(artiste);
            }
            
        } catch (SQLException e) {
            System.err.println("Une erreur s'est produite lors de la recherche : " + e.getMessage());
        }
        
        return artistes;
    }
    
    /**
     * Met à jour un artiste existant
     * @param artiste L'artiste avec les nouvelles informations
     * @return true si succès
     */
    public boolean modifier(Artiste artiste) {
        String sql = "UPDATE Artiste SET nom=?, prenom=?, nationalite=? WHERE id_artiste=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, artiste.getNom());
            stmt.setString(2, artiste.getPrenom());
            stmt.setString(3, artiste.getNationalite());
            stmt.setInt(4, artiste.getIdArtiste());
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Une erreur s'est produite lors de la modification de l'artiste : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Supprime un artiste
     * @param id L'ID de l'artiste à supprimer
     * @return true si succès
     */
    public boolean supprimer(int id) {
        String sql = "DELETE FROM Artiste WHERE id_artiste=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Une erreur s'est produite lors de la suppression de l'artiste : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Compte le nombre d'œuvres d'un artiste
     * @param idArtiste L'ID de l'artiste
     * @return Le nombre d'œuvres
     */
    public int compterOeuvres(int idArtiste) {
        String sql = "SELECT COUNT(*) as total FROM Oeuvre WHERE id_artiste=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idArtiste);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Vérifie si un artiste existe
     * @param id L'ID de l'artiste
     * @return true si l'artiste existe
     */
    public boolean existe(int id) {
        return getParId(id) != null;
    }
}