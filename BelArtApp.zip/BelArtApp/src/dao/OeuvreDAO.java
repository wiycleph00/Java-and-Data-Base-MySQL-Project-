package dao;

import models.Oeuvre;
import dao.database.DatabaseManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO pour gérer les oeuvres dans la base de données
 */
public class OeuvreDAO {
    
    /**
     * Ajoute une nouvelle oeuvre
     * @param oeuvre L'oeuvre à ajouter
     * @return true si succès
     */
    public boolean ajouter(Oeuvre oeuvre) {
        String sql = "INSERT INTO Oeuvre (titre, type, annee, id_artiste) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, oeuvre.getTitre());
            stmt.setString(2, oeuvre.getType());
            stmt.setInt(3, oeuvre.getAnnee());
            stmt.setInt(4, oeuvre.getIdArtiste());
            
            int rows = stmt.executeUpdate();
            
            if (rows > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    oeuvre.setIdOeuvre(rs.getInt(1));
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Une erreur s'est produite lors de l'ajout de l'oeuvre : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Récupère toutes les oeuvres avec les informations de l'artiste
     * @return Liste des oeuvres
     */
    public List<Oeuvre> getToutesAvecArtiste() {
        List<Oeuvre> oeuvres = new ArrayList<>();
        String sql = "SELECT o.*, a.nom, a.prenom FROM Oeuvre o " +
                     "JOIN Artiste a ON o.id_artiste = a.id_artiste " +
                     "ORDER BY o.annee DESC, o.titre";
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Oeuvre oeuvre = new Oeuvre(
                    rs.getInt("id_oeuvre"),
                    rs.getString("titre"),
                    rs.getString("type"),
                    rs.getInt("annee"),
                    rs.getInt("id_artiste"),
                    rs.getString("nom"),
                    rs.getString("prenom")
                );
                oeuvres.add(oeuvre);
            }
            
        } catch (SQLException e) {
            System.err.println("Une erreur s'est produite lors de la récupération des oeuvres : " + e.getMessage());
        }
        
        return oeuvres;
    }
    
    /**
     * Récupère une oeuvre par son ID
     * @param id L'ID de l'oeuvre
     * @return L'oeuvre ou null
     */
    public Oeuvre getParId(int id) {
        String sql = "SELECT o.*, a.nom, a.prenom FROM Oeuvre o " +
                     "JOIN Artiste a ON o.id_artiste = a.id_artiste " +
                     "WHERE o.id_oeuvre = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Oeuvre(
                    rs.getInt("id_oeuvre"),
                    rs.getString("titre"),
                    rs.getString("type"),
                    rs.getInt("annee"),
                    rs.getInt("id_artiste"),
                    rs.getString("nom"),
                    rs.getString("prenom")
                );
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Récupère les oeuvres d'un artiste
     * @param idArtiste L'ID de l'artiste
     * @return Liste des oeuvres
     */
    public List<Oeuvre> getParArtiste(int idArtiste) {
        List<Oeuvre> oeuvres = new ArrayList<>();
        String sql = "SELECT * FROM Oeuvre WHERE id_artiste=? ORDER BY annee DESC";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idArtiste);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Oeuvre oeuvre = new Oeuvre(
                    rs.getInt("id_oeuvre"),
                    rs.getString("titre"),
                    rs.getString("type"),
                    rs.getInt("annee"),
                    rs.getInt("id_artiste")
                );
                oeuvres.add(oeuvre);
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return oeuvres;
    }
    
    /**
     * Récupère les oeuvres d'une exposition
     * @param idExposition L'ID de l'exposition
     * @return Liste des oeuvres
     */
    public List<Oeuvre> getParExposition(int idExposition) {
        List<Oeuvre> oeuvres = new ArrayList<>();
        String sql = "SELECT o.*, a.nom, a.prenom FROM Oeuvre o " +
                     "JOIN Oeuvre_Exposition oe ON o.id_oeuvre = oe.id_oeuvre " +
                     "JOIN Artiste a ON o.id_artiste = a.id_artiste " +
                     "WHERE oe.id_exposition=? ORDER BY o.annee DESC";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idExposition);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Oeuvre oeuvre = new Oeuvre(
                    rs.getInt("id_oeuvre"),
                    rs.getString("titre"),
                    rs.getString("type"),
                    rs.getInt("annee"),
                    rs.getInt("id_artiste"),
                    rs.getString("nom"),
                    rs.getString("prenom")
                );
                oeuvres.add(oeuvre);
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return oeuvres;
    }
    
    /**
     * Filtre les oeuvres par type
     * @param type Le type d'oeuvre
     * @return Liste des oeuvres
     */
    public List<Oeuvre> getParType(String type) {
        List<Oeuvre> oeuvres = new ArrayList<>();
        String sql = "SELECT o.*, a.nom, a.prenom FROM Oeuvre o " +
                     "JOIN Artiste a ON o.id_artiste = a.id_artiste " +
                     "WHERE o.type=? ORDER BY o.annee DESC";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, type);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Oeuvre oeuvre = new Oeuvre(
                    rs.getInt("id_oeuvre"),
                    rs.getString("titre"),
                    rs.getString("type"),
                    rs.getInt("annee"),
                    rs.getInt("id_artiste"),
                    rs.getString("nom"),
                    rs.getString("prenom")
                );
                oeuvres.add(oeuvre);
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return oeuvres;
    }
    
    /**
     * Met à jour une oeuvre
     * @param oeuvre L'oeuvre à modifier
     * @return true si succès
     */
    public boolean modifier(Oeuvre oeuvre) {
        String sql = "UPDATE Oeuvre SET titre=?, type=?, annee=? WHERE id_oeuvre=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, oeuvre.getTitre());
            stmt.setString(2, oeuvre.getType());
            stmt.setInt(3, oeuvre.getAnnee());
            stmt.setInt(4, oeuvre.getIdOeuvre());
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Supprime une oeuvre
     * @param id L'ID de l'œuvre
     * @return true si succès
     */
    public boolean supprimer(int id) {
        String sql = "DELETE FROM Oeuvre WHERE id_oeuvre=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Vérifie si une oeuvre existe
     * @param id L'ID de l'oeuvre
     * @return true si l'oeuvre existe
     */
    public boolean existe(int id) {
        return getParId(id) != null;
    }
}