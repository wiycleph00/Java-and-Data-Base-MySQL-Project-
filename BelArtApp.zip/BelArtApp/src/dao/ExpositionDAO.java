package dao;

import models.Exposition;
import dao.database.DatabaseManager;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO pour sgérer les expositions dans la base de données
 */
public class ExpositionDAO {
    
    /**
     * Ajoute une nouvelle exposition
     */
    public boolean ajouter(Exposition expo) {
        String sql = "INSERT INTO Exposition (titre, date_debut, date_fin) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, expo.getTitre());
            stmt.setDate(2, Date.valueOf(expo.getDateDebut()));
            stmt.setDate(3, Date.valueOf(expo.getDateFin()));
            
            int rows = stmt.executeUpdate();
            
            if (rows > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    expo.setIdExposition(rs.getInt(1));
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Une erreur s'est produite lors de l'ajout de l'exposition : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Récupère toutes les expositions
     */
    public List<Exposition> getToutes() {
        List<Exposition> expositions = new ArrayList<>();
        String sql = "SELECT * FROM Exposition ORDER BY date_debut DESC";
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Exposition expo = new Exposition(
                    rs.getInt("id_exposition"),
                    rs.getString("titre"),
                    rs.getDate("date_debut").toLocalDate(),
                    rs.getDate("date_fin").toLocalDate()
                );
                expositions.add(expo);
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return expositions;
    }
    
    /**
     * Récupère une exposition par son ID
     */
    public Exposition getParId(int id) {
        String sql = "SELECT * FROM Exposition WHERE id_exposition=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Exposition(
                    rs.getInt("id_exposition"),
                    rs.getString("titre"),
                    rs.getDate("date_debut").toLocalDate(),
                    rs.getDate("date_fin").toLocalDate()
                );
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Récupère les expositions en cours
     */
    public List<Exposition> getEnCours() {
        List<Exposition> expositions = new ArrayList<>();
        LocalDate aujourdhui = LocalDate.now();
        String sql = "SELECT * FROM Exposition WHERE date_debut <= ? AND date_fin >= ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setDate(1, Date.valueOf(aujourdhui));
            stmt.setDate(2, Date.valueOf(aujourdhui));
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Exposition expo = new Exposition(
                    rs.getInt("id_exposition"),
                    rs.getString("titre"),
                    rs.getDate("date_debut").toLocalDate(),
                    rs.getDate("date_fin").toLocalDate()
                );
                expositions.add(expo);
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return expositions;
    }
    
    /**
     * Ajoute une oeuvre à une exposition
     */
    public boolean ajouterOeuvre(int idOeuvre, int idExposition) {
        String sql = "INSERT INTO Oeuvre_Exposition (id_oeuvre, id_exposition) VALUES (?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idOeuvre);
            stmt.setInt(2, idExposition);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            // Si erreur de clé dupliquée, l'oeuvre est déjà dans l'exposition
            if (e.getMessage().contains("Duplicate entry")) {
                System.out.println("Cette oeuvre existe déjà dans cette exposition.");
            } else {
                System.err.println("Erreur : " + e.getMessage());
            }
        }
        return false;
    }
    
    /**
     * Retire une oeuvre d'une exposition
     */
    public boolean retirerOeuvre(int idOeuvre, int idExposition) {
        String sql = "DELETE FROM Oeuvre_Exposition WHERE id_oeuvre=? AND id_exposition=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idOeuvre);
            stmt.setInt(2, idExposition);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Compte le nombre d'oeuvres dans une exposition
     */
    public int compterOeuvres(int idExposition) {
        String sql = "SELECT COUNT(*) as total FROM Oeuvre_Exposition WHERE id_exposition=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idExposition);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Récupère les expositions où se trouve une oeuvre
     */
    public List<Exposition> getParOeuvre(int idOeuvre) {
        List<Exposition> expositions = new ArrayList<>();
        String sql = "SELECT e.* FROM Exposition e " +
                     "JOIN Oeuvre_Exposition oe ON e.id_exposition = oe.id_exposition " +
                     "WHERE oe.id_oeuvre=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idOeuvre);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Exposition expo = new Exposition(
                    rs.getInt("id_exposition"),
                    rs.getString("titre"),
                    rs.getDate("date_debut").toLocalDate(),
                    rs.getDate("date_fin").toLocalDate()
                );
                expositions.add(expo);
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        
        return expositions;
    }
    
    /**
     * Supprime une exposition
     */
    public boolean supprimer(int id) {
        String sql = "DELETE FROM Exposition WHERE id_exposition=?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Vérifie si une exposition existe
     */
    public boolean existe(int id) {
        return getParId(id) != null;
    }
}