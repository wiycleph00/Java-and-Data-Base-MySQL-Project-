import models.*;
import dao.*;
import dao.database.DatabaseManager;
import utils.InputValidator;
import java.time.LocalDate;
import java.util.List;

public class Main {
    private static ArtisteDAO artisteDAO = new ArtisteDAO();
    private static OeuvreDAO oeuvreDAO = new OeuvreDAO();
    private static ExpositionDAO expositionDAO = new ExpositionDAO();

    public static void main(String[] args) {
        if (!DatabaseManager.testConnection()) {
            System.err.println("Impossible de se connecter à la base de données.");
            return;
        }
        
        boolean continuer = true;
        while (continuer) {
            InputValidator.clearScreen();
            afficherMenuPrincipal();
            int choix = InputValidator.lireEntier("Sélectionnez une option: ", false);
            
            switch (choix) {
                case 1: menuArtistes(); break;
                case 2: menuOeuvres(); break;
                case 3: menuExpositions(); break;
                case 4: menuConsultation(); break;
                case 0:
                    continuer = false;
                    System.out.println("\nMerci d'avoir utilisé BelArt. Au revoir!");
                    break;
                default:
                    System.out.println("Choix invalide.");
                    InputValidator.pause();
            }
        }
        DatabaseManager.closeConnection();
        InputValidator.fermer();
    }

    private static void afficherMenuPrincipal() {
        String ligneMenu = "+------------------------------------------+";
        System.out.println("\n" + ligneMenu);
        System.out.printf("| %-40s |%n", "        GALERIE D'ART BELART");
        System.out.println(ligneMenu);
        System.out.printf("| %-40s |%n", " 1. Gestion des Artistes");
        System.out.printf("| %-40s |%n", " 2. Gestion des Oeuvres");
        System.out.printf("| %-40s |%n", " 3. Gestion des Expositions");
        System.out.printf("| %-40s |%n", " 4. Consultation & Statistiques");
        System.out.printf("| %-40s |%n", " 0. Quitter");
        System.out.println(ligneMenu);
    }

    private static void menuArtistes() {
        boolean retour = false;
        while (!retour) {
            InputValidator.clearScreen();
            String ligneMenu = "+------------------------------------------+";
            
            System.out.println("\n" + ligneMenu);
            System.out.printf("| %-40s |%n", "          GESTION DES ARTISTES");
            System.out.println(ligneMenu);
            System.out.printf("| %-40s |%n", " 1. Ajouter un artiste");
            System.out.printf("| %-40s |%n", " 2. Afficher tous les artistes");
            System.out.printf("| %-40s |%n", " 3. Rechercher un artiste");
            System.out.printf("| %-40s |%n", " 4. Modifier un artiste");
            System.out.printf("| %-40s |%n", " 5. Supprimer un artiste");
            System.out.printf("| %-40s |%n", " 0. Retour au menu principal");
            System.out.println(ligneMenu);
            
            int choix = InputValidator.lireEntier("Sélectionnez une option : ", true);
            
            if (choix == 0) {
                retour = true;
                continue;
            }
            
            switch (choix) {
                case 1: ajouterArtiste(); break;
                case 2: afficherArtistes(); break;
                case 3: rechercherArtiste(); break;
                case 4: modifierArtiste(); break;
                case 5: supprimerArtiste(); break;
                default:
                    System.out.println("Choix invalide.");
                    InputValidator.pause();
            }
        }
    }

    private static void ajouterArtiste() {
        System.out.println("\n--- AJOUTER UN ARTISTE ---");
        System.out.println("(Tapez 'r' pour annuler)\n");
        
        String nom = InputValidator.lireChaine("Nom : ");
        if (nom == null) return;
        
        String prenom = InputValidator.lireChaine("Prénom : ");
        if (prenom == null) return;
        
        String nationalite = InputValidator.lireChaine("Nationalité : ");
        if (nationalite == null) return;
        
        Artiste artiste = new Artiste(nom, prenom, nationalite);
        if (artisteDAO.ajouter(artiste)) {
            System.out.println("Artiste ajouté avec succès ! (ID: " + artiste.getIdArtiste() + ")");
        } else {
            System.out.println("Erreur lors de l'ajout de l'artiste.");
        }
        InputValidator.pause();
    }

    private static void afficherArtistes() {
        List<Artiste> artistes = artisteDAO.getTous();
        if (artistes.isEmpty()) {
            System.out.println("La liste des artistes est actuellement vide.");
        } else {
            String ligne = "+------+---------------------+---------------------+---------------------+-----------+";

            System.out.println("\n" + ligne);
            System.out.printf("| %-82s |%n", "                              LISTE DES ARTISTES");
            System.out.println(ligne);
            System.out.printf("| %-4s | %-19s | %-19s | %-19s | %-9s |%n", "ID", "NOM", "PRENOM", "NATIONALITE", "OEUVRES");
            System.out.println(ligne);

            for (Artiste artiste : artistes) {
                int nbOeuvres = artisteDAO.compterOeuvres(artiste.getIdArtiste());
                System.out.printf("| %-4d | %-19s | %-19s | %-19s | %-9d |%n",
                        artiste.getIdArtiste(),
                        tronquer(artiste.getNom(), 19),
                        tronquer(artiste.getPrenom(), 19),
                        tronquer(artiste.getNationalite(), 19),
                        nbOeuvres);
            }
            System.out.println(ligne);
            System.out.println(" Total : " + artistes.size() + " artiste(s)");
        }
        InputValidator.pause();
    }

    private static void rechercherArtiste() {
        System.out.println("\n--- RECHERCHER UN ARTISTE ---\n");
        String nom = InputValidator.lireChaine("Nom de l'artiste à rechercher : ");
        if (nom == null) return;
        
        List<Artiste> resultats = artisteDAO.rechercherParNom(nom);
        if (resultats.isEmpty()) {
            System.out.println("\nL'artiste n'a pas été trouvé.");
        } else {
            System.out.println("\nArtiste trouvé " + resultats.size() + " résultat(s) :\n");
            for (Artiste artiste : resultats) {
                System.out.println(artiste);
            }
        }
        InputValidator.pause();
    }

    private static void modifierArtiste() {
        afficherArtistes();
        System.out.println("\n--- MODIFIER UN ARTISTE ---");
        int id = InputValidator.lireEntier("ID (0 pour annuler) : ", true);
        if (id <= 0) return;
        
        Artiste artiste = artisteDAO.getParId(id);
        if (artiste == null) {
            System.out.println("L'artiste est introuvable.");
            InputValidator.pause();
            return;
        }
        
        System.out.println("\nActuel : " + artiste);
        System.out.println("(Vide = conserver)\n");
        
        String nom = InputValidator.lireChaine("Nouveau nom [" + artiste.getNom() + "] : ");
        if (nom == null) return;
        if (!nom.isEmpty()) artiste.setNom(nom);
        
        String prenom = InputValidator.lireChaine("Nouveau prénom [" + artiste.getPrenom() + "] : ");
        if (prenom == null) return;
        if (!prenom.isEmpty()) artiste.setPrenom(prenom);
        
        String nationalite = InputValidator.lireChaine("Nouvelle nationalité [" + artiste.getNationalite() + "] : ");
        if (nationalite == null) return;
        if (!nationalite.isEmpty()) artiste.setNationalite(nationalite);
        
        if (artisteDAO.modifier(artiste)) {
            System.out.println("\nLes changements ont été pris en compte");
        } else {
            System.out.println("\nIl y a eu une erreur lors de la modification.");
        }
        InputValidator.pause();
    }

    private static void supprimerArtiste() {
        afficherArtistes();
        System.out.println("\n--- SUPPRIMER UN ARTISTE ---");
        int id = InputValidator.lireEntier("ID (0 pour annuler) : ", true);
        if (id <= 0) return;
        
        Artiste artiste = artisteDAO.getParId(id);
        if (artiste == null) {
            System.out.println("L'artiste est introuvable.");
            InputValidator.pause();
            return;
        }
        
        int nbOeuvres = artisteDAO.compterOeuvres(id);
        System.out.println("\nAttention : " + nbOeuvres + " le(s) oeuvre(s) de l'artiste seront aussi supprimées !");
        
        if (InputValidator.confirmer("\nSupprimer " + artiste.getNomComplet() + " ?")) {
            if (artisteDAO.supprimer(id)) {
                System.out.println("L'artiste a été supprimé avec succès.");
            } else {
                System.out.println("Erreur lors de la suppréssion de l'artiste.");
            }
        } else {
            System.out.println("Annulé.");
        }
        InputValidator.pause();
    }

    private static void menuOeuvres() {
        boolean retour = false;
        while (!retour) {
            InputValidator.clearScreen();
            String ligneMenu = "+------------------------------------------+";
            
            System.out.println("\n" + ligneMenu);
            System.out.printf("| %-40s |%n", "           GESTION DES OEUVRES");
            System.out.println(ligneMenu);
            System.out.printf("| %-40s |%n", " 1. Ajouter une oeuvre");
            System.out.printf("| %-40s |%n", " 2. Afficher toutes les oeuvres");
            System.out.printf("| %-40s |%n", " 3. Filtrer par type");
            System.out.printf("| %-40s |%n", " 4. Modifier une oeuvre");
            System.out.printf("| %-40s |%n", " 5. Supprimer une oeuvre");
            System.out.printf("| %-40s |%n", " 0. Retour au menu principal");
            System.out.println(ligneMenu);

            int choix = InputValidator.lireEntier("Sélectionnez une option : ", true);
            
            if (choix == 0) {
                retour = true;
                continue;
            }
            
            switch (choix) {
                case 1: ajouterOeuvre(); break;
                case 2: afficherOeuvres(); break;
                case 3: filtrerOeuvresParType(); break;
                case 4: modifierOeuvre(); break;
                case 5: supprimerOeuvre(); break;
                default:
                    System.out.println("Choix invalide.");
                    InputValidator.pause();
            }
        }
    }

    private static void ajouterOeuvre() {
        System.out.println("\n--- AJOUTER UNE OEUVRE ---\n");
        afficherArtistes();
        System.out.println();
        
        int idArtiste = InputValidator.lireEntier("ID artiste (0 pour annuler) : ", true);
        if (idArtiste <= 0) return;
        
        if (!artisteDAO.existe(idArtiste)) {
            System.out.println("L'artiste est inexistant.");
            InputValidator.pause();
            return;
        }
        
        String titre = InputValidator.lireChaine("Titre : ");
        if (titre == null) return;
        
        System.out.println("\nTypes : Tableau, Sculpture, Photographie, Autre");
        String type = InputValidator.lireChaine("Type : ");
        if (type == null) return;
        
        int annee = InputValidator.lireEntier("Année (0 pour annuler) : ", true);
        if (annee <= 0) return;
        
        if (annee < 1000 || annee > LocalDate.now().getYear()) {
            System.out.println("Année invalide.");
            InputValidator.pause();
            return;
        }
        
        Oeuvre oeuvre = new Oeuvre(titre, type, annee, idArtiste);
        if (oeuvreDAO.ajouter(oeuvre)) {
            System.out.println("\nOeuvre ajoutée avec succès ! (ID: " + oeuvre.getIdOeuvre() + ")");
        } else {
            System.out.println("\nErreur lors de l'oeuvre.");
        }
        InputValidator.pause();
    }

    private static void afficherOeuvres() {
        List<Oeuvre> oeuvres = oeuvreDAO.getToutesAvecArtiste();
        String ligne = "+------+---------------------------+-----------------+----------+--------------------------+";
        
        System.out.println("\n" + ligne);
        System.out.printf("| %-88s |%n", "                                  LISTE DES OEUVRES");
        System.out.println(ligne);
        System.out.printf("| %-4s | %-25s | %-15s | %-8s | %-24s |%n", "ID", "TITRE", "TYPE", "ANNEE", "ARTISTE");
        System.out.println(ligne);

        for (Oeuvre o : oeuvres) {
            String nomArtiste = tronquer(o.getPrenomArtiste() + " " + o.getNomArtiste(), 25);
            System.out.printf("| %-4d | %-25s | %-15s | %-8d | %-24s |%n",
                    o.getIdOeuvre(), 
                    tronquer(o.getTitre(), 25), 
                    tronquer(o.getType(), 15), 
                    o.getAnnee(), 
                    nomArtiste);
        }
        System.out.println(ligne);
        InputValidator.pause();
    }

    private static void filtrerOeuvresParType() {
        System.out.println("\n--- FILTRER PAR TYPE ---\n");
        System.out.println("Types : Tableau, Sculpture, Photographie, Autre");
        String type = InputValidator.lireChaine("Type : ");
        if (type == null) return;
        
        List<Oeuvre> oeuvres = oeuvreDAO.getParType(type);
        if (oeuvres.isEmpty()) {
            System.out.println("\nAucune oeuvre de type \"" + type + "\".");
        } else {
            System.out.println("\nCe type existe " + oeuvres.size() + " oeuvre(s) :\n");
            for (Oeuvre oeuvre : oeuvres) {
                System.out.println(oeuvre);
            }
        }
        InputValidator.pause();
    }

    private static void modifierOeuvre() {
        afficherOeuvres();
        System.out.println("\n--- MODIFIER UNE OEUVRE ---");
        int id = InputValidator.lireEntier("ID (0 pour annuler) : ", true);
        if (id <= 0) return;
        
        Oeuvre oeuvre = oeuvreDAO.getParId(id);
        if (oeuvre == null) {
            System.out.println("L'oeuvre est introuvable.");
            InputValidator.pause();
            return;
        }
        
        System.out.println("\nActuel : " + oeuvre);
        System.out.println("(Vide = conserver)\n");
        
        String titre = InputValidator.lireChaine("Nouveau titre [" + oeuvre.getTitre() + "] : ");
        if (titre == null) return;
        if (!titre.isEmpty()) oeuvre.setTitre(titre);
        
        String type = InputValidator.lireChaine("Nouveau type [" + oeuvre.getType() + "] : ");
        if (type == null) return;
        if (!type.isEmpty()) oeuvre.setType(type);
        
        System.out.print("Nouvelle année [" + oeuvre.getAnnee() + "] (0 = conserver) : ");
        int annee = InputValidator.lireEntier("", true);
        if (annee == -1) return;
        if (annee > 0) oeuvre.setAnnee(annee);
        
        if (oeuvreDAO.modifier(oeuvre)) {
            System.out.println("\nModification enrégistrée avec succès");
        } else {
            System.out.println("\nErreur lors de la modification.");
        }
        InputValidator.pause();
    }

    private static void supprimerOeuvre() {
        afficherOeuvres();
        System.out.println("\n--- SUPPRIMER UNE OEUVRE ---");
        int id = InputValidator.lireEntier("ID (0 pour annuler) : ", true);
        if (id <= 0) return;
        
        Oeuvre oeuvre = oeuvreDAO.getParId(id);
        if (oeuvre == null) {
            System.out.println("L'oeuvre est introuvable.");
            InputValidator.pause();
            return;
        }
        
        if (InputValidator.confirmer("\nSupprimer \"" + oeuvre.getTitre() + "\" ?")) {
            if (oeuvreDAO.supprimer(id)) {
                System.out.println("L'oeuvre a été supprimée.");
            } else {
                System.out.println("Erreur lors de la suppression de l'oeuvre.");
            }
        } else {
            System.out.println("Annulé.");
        }
        InputValidator.pause();
    }

    private static void menuExpositions() {
        boolean retour = false;
        while (!retour) {
            InputValidator.clearScreen();
            String ligneMenu = "+------------------------------------------+";
            
            System.out.println("\n" + ligneMenu);
            System.out.printf("| %-40s |%n", "         GESTION DES EXPOSITIONS");
            System.out.println(ligneMenu);
            System.out.printf("| %-40s |%n", " 1. Créer une exposition");
            System.out.printf("| %-40s |%n", " 2. Afficher toutes les expositions");
            System.out.printf("| %-40s |%n", " 3. Ajouter une oeuvre à une expo");
            System.out.printf("| %-40s |%n", " 4. Retirer une oeuvre d'une expo");
            System.out.printf("| %-40s |%n", " 5. Supprimer une exposition");
            System.out.printf("| %-40s |%n", " 0. Retour au menu principal");
            System.out.println(ligneMenu);

            int choix = InputValidator.lireEntier("Sélectionnez une option : ", true);
            
            if (choix == 0) {
                retour = true;
                continue;
            }
            
            switch (choix) {
                case 1: creerExposition(); break;
                case 2: afficherExpositions(); break;
                case 3: ajouterOeuvreExposition(); break;
                case 4: retirerOeuvreExposition(); break;
                case 5: supprimerExposition(); break;
                default:
                    System.out.println("Choix invalide.");
                    InputValidator.pause();
            }
        }
    }

    private static void creerExposition() {
        System.out.println("\n--- CRÉER UNE EXPOSITION ---\n");
        
        String titre = InputValidator.lireChaine("Titre : ");
        if (titre == null) return;
        
        LocalDate dateDebut = InputValidator.lireDate("Date de début");
        if (dateDebut == null) return;
        
        LocalDate dateFin = InputValidator.lireDate("Date de fin");
        if (dateFin == null) return;
        
        Exposition expo = new Exposition(titre, dateDebut, dateFin);
        if (!expo.datesValides()) {
            System.out.println("\nDate fin doit être après Date début.");
            InputValidator.pause();
            return;
        }
        
        if (expositionDAO.ajouter(expo)) {
            System.out.println("\nL'exposition été créée ! (ID: " + expo.getIdExposition() + ")");
        } else {
            System.out.println("\nErreur lors de la création de l'exposition.");
        }
        InputValidator.pause();
    }

    private static void afficherExpositions() {
        List<Exposition> expos = expositionDAO.getToutes();
        String ligne = "+------+--------------------------------+--------------+--------------+-------------+";
        
        System.out.println("\n" + ligne);
        System.out.printf("| %-78s %n", "                                    LISTE DES EXPOSITIONS");
        System.out.println(ligne);
        System.out.printf("| %-4s | %-30s | %-12s | %-12s | %-11s |%n", "ID", "TITRE", "DEBUT", "FIN", "OEUVRES");
        System.out.println(ligne);

        for (Exposition e : expos) {
            System.out.printf("| %-4d | %-30s | %-12s | %-12s | %-11d |%n",
                    e.getIdExposition(), 
                    tronquer(e.getTitre(), 30), 
                    e.getDateDebut(), 
                    e.getDateFin(), 
                    expositionDAO.compterOeuvres(e.getIdExposition()));
        }
        System.out.println(ligne);
        InputValidator.pause();
    }

    private static void ajouterOeuvreExposition() {
        System.out.println("\n--- AJOUTER OEUVRE À EXPOSITION ---\n");
        afficherExpositions();
        System.out.println();
        
        int idExpo = InputValidator.lireEntier("ID exposition (0 pour annuler) : ", true);
        if (idExpo <= 0) return;
        
        if (!expositionDAO.existe(idExpo)) {
            System.out.println("Exposition inexistante.");
            InputValidator.pause();
            return;
        }
        
        afficherOeuvres();
        System.out.println();
        
        int idOeuvre = InputValidator.lireEntier("ID oeuvre (0 pour annuler) : ", true);
        if (idOeuvre <= 0) return;
        
        if (!oeuvreDAO.existe(idOeuvre)) {
            System.out.println("Oeuvre inexistante.");
            InputValidator.pause();
            return;
        }
        
        if (expositionDAO.ajouterOeuvre(idOeuvre, idExpo)) {
            System.out.println("\nL'euvre a été ajoutée !");
        } else {
            System.out.println("\nErreur lors de l'ajout de l'oeuvre.");
        }
        InputValidator.pause();
    }

    private static void retirerOeuvreExposition() {
        System.out.println("\n--- RETIRER OEUVRE D'EXPOSITION ---\n");
        afficherExpositions();
        System.out.println();
        
        int idExpo = InputValidator.lireEntier("ID exposition (0 pour annuler) : ", true);
        if (idExpo <= 0) return;
        
        List<Oeuvre> oeuvres = oeuvreDAO.getParExposition(idExpo);
        if (oeuvres.isEmpty()) {
            System.out.println("\nIl n'y a aucune oeuvre dans cette exposition.");
            InputValidator.pause();
            return;
        }
        
        System.out.println("\nOeuvres de cette exposition :");
        for (Oeuvre o : oeuvres) {
            System.out.println(o);
        }
        System.out.println();
        
        int idOeuvre = InputValidator.lireEntier("ID oeuvre à retirer (0 pour annuler) : ", true);
        if (idOeuvre <= 0) return;
        
        if (expositionDAO.retirerOeuvre(idOeuvre, idExpo)) {
            System.out.println("\nOeuvre retirée !");
        } else {
            System.out.println("\nErreur.");
        }
        InputValidator.pause();
    }

    private static void supprimerExposition() {
        afficherExpositions();
        System.out.println("\n--- SUPPRIMER UNE EXPOSITION ---");
        int id = InputValidator.lireEntier("ID (0 pour annuler) : ", true);
        if (id <= 0) return;
        
        Exposition expo = expositionDAO.getParId(id);
        if (expo == null) {
            System.out.println("L'exposition est introuvable.");
            InputValidator.pause();
            return;
        }
        
        if (InputValidator.confirmer("\nSupprimer \"" + expo.getTitre() + "\" ?")) {
            if (expositionDAO.supprimer(id)) {
                System.out.println("L'exposition a été supprimée.");
            } else {
                System.out.println("Erreur lors de la suppression de l'exposition.");
            }
        } else {
            System.out.println("Annulé.");
        }
        InputValidator.pause();
    }

    private static void menuConsultation() {
        boolean retour = false;
        while (!retour) {
            InputValidator.clearScreen();
            String ligneMenu = "+------------------------------------------+";
            
            System.out.println("\n" + ligneMenu);
            System.out.printf("| %-40s |%n", "      CONSULTATION & STATISTIQUES");
            System.out.println(ligneMenu);
            System.out.printf("| %-40s |%n", " === RECHERCHE ===");
            System.out.printf("| %-40s |%n", " 1. Oeuvres d'un artiste");
            System.out.printf("| %-40s |%n", " 2. Oeuvres par type");
            System.out.printf("| %-40s |%n", " 3. Oeuvres d'une exposition");
            System.out.printf("| %-40s |%n", " 4. Expositions d'une oeuvre");
            System.out.printf("| %-40s |%n", " 5. Expositions en cours");
            System.out.printf("| %-40s |%n", "");
            System.out.printf("| %-40s |%n", " === STATISTIQUES ===");
            System.out.printf("| %-40s |%n", " 6. Statistiques générales");
            System.out.printf("| %-40s |%n", "");
            System.out.printf("| %-40s |%n", " 0. Retour au menu principal");
            System.out.println(ligneMenu);

            int choix = InputValidator.lireEntier("Sélectionnez une option : ", true);
            
            if (choix == 0) {
                retour = true;
                continue;
            }
            
            switch (choix) {
                case 1: voirOeuvresArtiste(); break;
                case 2: filtrerOeuvresParType(); break;
                case 3: voirOeuvresExposition(); break;
                case 4: voirExpositionsOeuvre(); break;
                case 5: afficherExpositionsEnCours(); break;
                case 6: menuStatistiques(); break;
                default:
                    System.out.println("Choix invalide.");
                    InputValidator.pause();
            }
        }
    }

    private static void voirOeuvresArtiste() {
        afficherArtistes();
        System.out.println("\n--- OEUVRES D'UN ARTISTE ---");
        int id = InputValidator.lireEntier("ID artiste (0 pour annuler) : ", true);
        if (id <= 0) return;
        
        Artiste artiste = artisteDAO.getParId(id);
        if (artiste == null) {
            System.out.println("Introuvable.");
            InputValidator.pause();
            return;
        }
        
        List<Oeuvre> oeuvres = oeuvreDAO.getParArtiste(id);
        System.out.println("\nOeuvres de " + artiste.getNomComplet() + " :\n");
        if (oeuvres.isEmpty()) {
            System.out.println("Aucune oeuvre.");
        } else {
            for (Oeuvre o : oeuvres) {
                System.out.println("• \"" + o.getTitre() + "\" (" + o.getType() + ", " + o.getAnnee() + ")");
            }
        }
        InputValidator.pause();
    }

    private static void voirOeuvresExposition() {
        afficherExpositions();
        System.out.println("\n--- OEUVRES D'UNE EXPOSITION ---");
        int id = InputValidator.lireEntier("ID exposition (0 pour annuler) : ", true);
        if (id <= 0) return;
        
        Exposition expo = expositionDAO.getParId(id);
        if (expo == null) {
            System.out.println("Introuvable.");
            InputValidator.pause();
            return;
        }
        
        List<Oeuvre> oeuvres = oeuvreDAO.getParExposition(id);
        System.out.println("\nOeuvres de \"" + expo.getTitre() + "\" :\n");
        if (oeuvres.isEmpty()) {
            System.out.println("Aucune oeuvre.");
        } else {
            for (Oeuvre o : oeuvres) {
                System.out.println(o);
            }
        }
        InputValidator.pause();
    }

    private static void voirExpositionsOeuvre() {
        afficherOeuvres();
        System.out.println("\n--- EXPOSITIONS D'UNE OEUVRE ---");
        int id = InputValidator.lireEntier("ID oeuvre (0 pour annuler) : ", true);
        if (id <= 0) return;
        
        Oeuvre oeuvre = oeuvreDAO.getParId(id);
        if (oeuvre == null) {
            System.out.println("Introuvable.");
            InputValidator.pause();
            return;
        }
        
        List<Exposition> expositions = expositionDAO.getParOeuvre(id);
        System.out.println("\nExpositions de \"" + oeuvre.getTitre() + "\" :\n");
        if (expositions.isEmpty()) {
            System.out.println("Aucune exposition.");
        } else {
            for (Exposition expo : expositions) {
                System.out.println(expo);
            }
        }
        InputValidator.pause();
    }

    private static void afficherExpositionsEnCours() {
        List<Exposition> expositions = expositionDAO.getToutes();
        String ligne = "+------+------------------------------+--------------+--------------+----------+";
        
        System.out.println("\n" + ligne);
        System.out.printf("| %-78s |%n", "                    EXPOSITIONS ACTUELLEMENT EN COURS");
        System.out.println(ligne);
        System.out.printf("| %-4s | %-28s | %-12s | %-12s | %-8s |%n", "ID", "TITRE", "DEBUT", "FIN", "OEUVRES");
        System.out.println(ligne);

        for (Exposition expo : expositions) {
            if (expo.estEnCours()) {
                int nbOeuvres = expositionDAO.compterOeuvres(expo.getIdExposition());
                System.out.printf("| %-4d | %-28s | %-12s | %-12s | %-8d |%n",
                        expo.getIdExposition(),
                        tronquer(expo.getTitre(), 28),
                        expo.getDateDebut(),
                        expo.getDateFin(),
                        nbOeuvres);
            }
        }
        System.out.println(ligne);
        InputValidator.pause();
    }

    private static void menuStatistiques() {
        InputValidator.clearScreen();
        String ligneMenu = "+------------------------------------------+";
        
        System.out.println("\n" + ligneMenu);
        System.out.printf("| %-40s |%n", "       STATISTIQUES GÉNÉRALES");
        System.out.println(ligneMenu);
        
        List<Artiste> artistes = artisteDAO.getTous();
        List<Oeuvre> oeuvres = oeuvreDAO.getToutesAvecArtiste();
        List<Exposition> expositions = expositionDAO.getToutes();
        
        System.out.printf("| %-40s |%n", "");
        System.out.printf("| %-40s |%n", "Vue d'ensemble :");
        System.out.printf("| %-40s |%n", "    Artistes : " + artistes.size());
        System.out.printf("| %-40s |%n", "    Oeuvres : " + oeuvres.size());
        System.out.printf("| %-40s |%n", "    Expositions : " + expositions.size());
        System.out.printf("| %-40s |%n", "    Expositions en cours : " + expositionDAO.getEnCours().size());
        System.out.printf("| %-40s |%n", "");
        
        if (!artistes.isEmpty()) {
            Artiste artisteMax = null;
            int maxOeuvres = 0;
            for (Artiste a : artistes) {
                int nb = artisteDAO.compterOeuvres(a.getIdArtiste());
                if (nb > maxOeuvres) {
                    maxOeuvres = nb;
                    artisteMax = a;
                }
            }
            if (artisteMax != null && maxOeuvres > 0) {
                System.out.printf("| %-40s |%n", "Artiste le plus prolifique :");
                String ligne = "   • " + tronquer(artisteMax.getNomComplet() + " (" + maxOeuvres + " oeuvres)", 37);
                System.out.printf("| %-40s |%n", ligne);
                System.out.printf("| %-40s |%n", "");
            }
        }
        
        if (!expositions.isEmpty()) {
            Exposition expoMax = null;
            int maxOeuvres = 0;
            for (Exposition e : expositions) {
                int nb = expositionDAO.compterOeuvres(e.getIdExposition());
                if (nb > maxOeuvres) {
                    maxOeuvres = nb;
                    expoMax = e;
                }
            }
            if (expoMax != null && maxOeuvres > 0) {
                System.out.printf("| %-40s |%n", "Exposition la plus fournie :");
                String ligne = "   • " + tronquer(expoMax.getTitre() + " (" + maxOeuvres + " oeuvres)", 37);
                System.out.printf("| %-40s |%n", ligne);
                System.out.printf("| %-40s |%n", "");
            }
        }
        
        if (!oeuvres.isEmpty()) {
            System.out.printf("| %-40s |%n", "Répartition par type :");
            java.util.Map<String, Integer> repartition = new java.util.HashMap<>();
            for (Oeuvre o : oeuvres) {
                String type = o.getType();
                repartition.put(type, repartition.getOrDefault(type, 0) + 1);
            }
            for (java.util.Map.Entry<String, Integer> entry : repartition.entrySet()) {
                String ligne = "   • " + entry.getKey() + " : " + entry.getValue();
                System.out.printf("| %-40s |%n", ligne);
            }
            System.out.printf("| %-40s |%n", "");
        }
        
        if (!oeuvres.isEmpty()) {
            System.out.printf("| %-40s |%n", "Répartition par période :");
            java.util.Map<String, Integer> parDecennie = new java.util.HashMap<>();
            for (Oeuvre o : oeuvres) {
                int decennie = (o.getAnnee() / 10) * 10;
                String periode = decennie + "s";
                parDecennie.put(periode, parDecennie.getOrDefault(periode, 0) + 1);
            }
            java.util.List<java.util.Map.Entry<String, Integer>> sorted =
                new java.util.ArrayList<>(parDecennie.entrySet());
            sorted.sort((a, b) -> a.getKey().compareTo(b.getKey()));
            for (java.util.Map.Entry<String, Integer> entry : sorted) {
                String ligne = "   • " + entry.getKey() + " : " + entry.getValue() + " oeuvre(s)";
                System.out.printf("| %-40s |%n", ligne);
            }
            System.out.printf("| %-40s |%n", "");
        }
        
        System.out.println(ligneMenu);
        InputValidator.pause();
    }

    private static String tronquer(String texte, int longueurMax) {
        if (texte == null) return "";
        if (texte.length() <= longueurMax) return texte;
        return texte.substring(0, longueurMax - 3) + "...";
    }
}
