package models;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Classe pour creer un objet exposition 
 */
public class Exposition {
    private int idExposition;
    private String titre;
    private LocalDate dateDebut;
    private LocalDate dateFin;
    
    // Constructeur de la classe
    public Exposition(int idExposition, String titre, LocalDate dateDebut, LocalDate dateFin) {
        this.idExposition = idExposition;
        this.titre = titre;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
    }
    
    // Constructeur de la classe sans ID (pour créer une nouvelle exposition)
    public Exposition(String titre, LocalDate dateDebut, LocalDate dateFin) {
        this.titre = titre;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
    }
    
    // Getters
    public int getIdExposition() {
        return idExposition;
    }
    
    public String getTitre() {
        return titre;
    }
    
    public LocalDate getDateDebut() {
        return dateDebut;
    }
    
    public LocalDate getDateFin() {
        return dateFin;
    }
    
    // Setters
    public void setIdExposition(int idExposition) {
        this.idExposition = idExposition;
    }
    
    public void setTitre(String titre) {
        this.titre = titre;
    }
    
    public void setDateDebut(LocalDate dateDebut) {
        this.dateDebut = dateDebut;
    }
    
    public void setDateFin(LocalDate dateFin) {
        this.dateFin = dateFin;
    }
    
    // Méthode pour vérifier si les dates sont valides
    public boolean datesValides() {
        return dateFin.isAfter(dateDebut) || dateFin.isEqual(dateDebut);
    }
    
    // Méthode pour vérifier si une exposition est en cours
    public boolean estEnCours() {
        LocalDate aujourdhui = LocalDate.now();
        return !aujourdhui.isBefore(dateDebut) && !aujourdhui.isAfter(dateFin);
    }
    
    // affichage
    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String statut = estEnCours() ? " [EN COURS]" : "";
        return String.format("ID: %d | \"%s\" (du %s au %s)%s",
            idExposition, titre, 
            dateDebut.format(formatter), 
            dateFin.format(formatter),
            statut);
    }
}