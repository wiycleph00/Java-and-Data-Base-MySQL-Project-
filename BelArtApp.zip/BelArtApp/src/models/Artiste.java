package models;

/**
 * Classe pour creer un objet artiste
 */
public class Artiste {
    private int idArtiste;
    private String nom;
    private String prenom;
    private String nationalite;
    
    // Constructeur de la classe  
    public Artiste(int idArtiste, String nom, String prenom, String nationalite) {
        this.idArtiste = idArtiste;
        this.nom = nom;
        this.prenom = prenom;
        this.nationalite = nationalite;
    }
    
    // Constructeur de la classe mais sans ID (pour créer un nouvel artiste)
    public Artiste(String nom, String prenom, String nationalite) {
        this.nom = nom;
        this.prenom = prenom;
        this.nationalite = nationalite;
    }
    
    // Getters
    public int getIdArtiste() {
        return idArtiste;
    }
    
    public String getNom() {
        return nom;
    }
    
    public String getPrenom() {
        return prenom;
    }
    
    public String getNationalite() {
        return nationalite;
    }
    
    // Setters
    public void setIdArtiste(int idArtiste) {
        this.idArtiste = idArtiste;
    }
    
    public void setNom(String nom) {
        this.nom = nom;
    }
    
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    
    public void setNationalite(String nationalite) {
        this.nationalite = nationalite;
    }
    
    // Méthode pour afficher l'artiste
    @Override
    public String toString() {
        return String.format("ID: %d | %s %s (%s)", 
            idArtiste, prenom, nom, nationalite);
    }
    
    // Méthode pour afficher le nom complet
    public String getNomComplet() {
        return prenom + " " + nom;
    }
}