package models;

/**
 * Classe pour creer un objet oeuvre
 */
public class Oeuvre {
    private int idOeuvre;
    private String titre;
    private String type;
    private int annee;
    private int idArtiste;
    private String nomArtiste;
    private String prenomArtiste; 
    
    // Constructeur complet avec les informations de l'artiste
    public Oeuvre(int idOeuvre, String titre, String type, int annee, 
                  int idArtiste, String nomArtiste, String prenomArtiste) {
        this.idOeuvre = idOeuvre;
        this.titre = titre;
        this.type = type;
        this.annee = annee;
        this.idArtiste = idArtiste;
        this.nomArtiste = nomArtiste;
        this.prenomArtiste = prenomArtiste;
    }
    
    // Constructeur sans les informations de l'artiste
    public Oeuvre(int idOeuvre, String titre, String type, int annee, int idArtiste) {
        this.idOeuvre = idOeuvre;
        this.titre = titre;
        this.type = type;
        this.annee = annee;
        this.idArtiste = idArtiste;
    }
    
    // Constructeur sans ID (pour créer une nouvelle œuvre)
    public Oeuvre(String titre, String type, int annee, int idArtiste) {
        this.titre = titre;
        this.type = type;
        this.annee = annee;
        this.idArtiste = idArtiste;
    }
    
    // Getters
    public int getIdOeuvre() {
        return idOeuvre;
    }
    
    public String getTitre() {
        return titre;
    }
    
    public String getType() {
        return type;
    }
    
    public int getAnnee() {
        return annee;
    }
    
    public int getIdArtiste() {
        return idArtiste;
    }
    
    public String getNomArtiste() {
        return nomArtiste;
    }
    
    public String getPrenomArtiste() {
        return prenomArtiste;
    }
    
    // Setters
    public void setIdOeuvre(int idOeuvre) {
        this.idOeuvre = idOeuvre;
    }
    
    public void setTitre(String titre) {
        this.titre = titre;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public void setAnnee(int annee) {
        this.annee = annee;
    }
    
    public void setIdArtiste(int idArtiste) {
        this.idArtiste = idArtiste;
    }
    
    public void setNomArtiste(String nomArtiste) {
        this.nomArtiste = nomArtiste;
    }
    
    public void setPrenomArtiste(String prenomArtiste) {
        this.prenomArtiste = prenomArtiste;
    }
    
    // Affichage 
    @Override
    public String toString() {
        if (nomArtiste != null && prenomArtiste != null) {
            return String.format("ID: %d | \"%s\" (%s, %d) - par %s %s",
                idOeuvre, titre, type, annee, prenomArtiste, nomArtiste);
        } else {
            return String.format("ID: %d | \"%s\" (%s, %d)",
                idOeuvre, titre, type, annee);
        }
    }
}
